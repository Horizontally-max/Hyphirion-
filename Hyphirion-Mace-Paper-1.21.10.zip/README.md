# Hyphirion Mace — Paper 1.21.10

A Maven project for a Paper 1.21.10 server. Requires Java 21.

## Build in GitHub Codespaces or on a computer

1. Upload/extract this project into a repository or Codespace.
2. In the project terminal, run:

   ```bash
   mvn package
   ```

3. The plugin JAR will be created at:

   `target/HyphirionMace-1.21.10.jar`

4. Put the JAR in your Paper server's `plugins` folder and restart the server.

## Commands

- `/hyphirion give <player>` — gives the genuine mace (operator permission by default).
- Permission: `hyphirion.admin`

## Recipe

A shaped 3×3 recipe:

```text
N S N
N M N
N N N
```

- `N` = Netherite Ingot
- `S` = Nether Star
- `M` = Mace

## Ability controls

- Divine Thunder: right-click while grounded.
- World Breaker: sneak + right-click while grounded.
- Void Collapse: double left-click while holding the mace.
- God Mode: sneak + right-click while grounded and looking upward.
- Heaven's Judgment: aim at a target, then sneak + swap hands (F by default on Java).
- Skybreaker Dash: double-tap jump / the server's flight-toggle input while holding the mace.
- Divine Dive: sneak + right-click while airborne.

## Notes and limitations

- All seven abilities are implemented with Bukkit/Paper events and particles/sounds.
- Terrain is never intentionally modified; impact effects are visual only.
- Double-left-click is detected from arm-swing events. Minecraft client/server timing and attack animation can affect reliability.
- Skybreaker Dash uses the flight-toggle event as a double-jump trigger. Server settings or other movement plugins may interfere.
- Paper plugins cannot add new client keybinds. Controls rely on existing Minecraft inputs.
- This project is provided as a source project; it has not been compiled in this environment. If Maven reports an API/version resolution error, check that the server API version is available in the Paper Maven repository and adjust the dependency version to the exact published snapshot.
