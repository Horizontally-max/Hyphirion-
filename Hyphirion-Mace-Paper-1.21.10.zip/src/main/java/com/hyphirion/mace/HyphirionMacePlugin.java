package com.hyphirion.mace;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

public final class HyphirionMacePlugin extends JavaPlugin implements Listener {
    private NamespacedKey maceKey;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    private final Map<UUID, Long> lastSwing = new HashMap<>();
    private final Map<UUID, Long> lastJumpTrigger = new HashMap<>();
    private final Set<UUID> godMode = new HashSet<>();
    private final Map<UUID, Long> diveStarted = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maceKey = new NamespacedKey(this, "hyphirion_mace");
        getServer().getPluginManager().registerEvents(this, this);
        registerRecipe();
        getLogger().info("Hyphirion Mace enabled.");
    }

    @Override
    public void onDisable() {
        for (UUID id : new HashSet<>(godMode)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) clearGodMode(p);
        }
    }

    private ItemStack createMace() {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "Hyphirion Mace");
        meta.setLore(List.of(
                ChatColor.LIGHT_PURPLE + "A weapon forged beyond the heavens",
                ChatColor.GRAY + "Seven powers. No mercy.",
                ChatColor.DARK_PURPLE + "Right-click, sneak, and strike."
        ));
        meta.addEnchant(Enchantment.UNBREAKING, 5, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.getPersistentDataContainer().set(maceKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isHyphirion(ItemStack item) {
        if (item == null || item.getType() != Material.MACE || !item.hasItemMeta()) return false;
        Byte tag = item.getItemMeta().getPersistentDataContainer().get(maceKey, PersistentDataType.BYTE);
        return tag != null && tag == (byte) 1;
    }

    private void registerRecipe() {
        NamespacedKey key = new NamespacedKey(this, "hyphirion_mace_recipe");
        Bukkit.removeRecipe(key);
        ShapedRecipe recipe = new ShapedRecipe(key, createMace());
        recipe.shape("NSN", "NMN", "NNN");
        recipe.setIngredient('N', Material.NETHERITE_INGOT);
        recipe.setIngredient('S', Material.NETHER_STAR);
        recipe.setIngredient('M', Material.MACE);
        Bukkit.addRecipe(recipe);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("hyphirion")) return false;
        if (!sender.hasPermission("hyphirion.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission.");
            return true;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "That player is not online.");
                return true;
            }
            target.getInventory().addItem(createMace()).values()
                    .forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
            sender.sendMessage(ChatColor.LIGHT_PURPLE + "Gave the Hyphirion Mace to " + target.getName() + ".");
            target.sendMessage(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "You received the Hyphirion Mace!");
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Usage: /hyphirion give <player>");
        return true;
    }

    private boolean onCooldown(Player p, String ability, long millis) {
        long now = System.currentTimeMillis();
        Map<String, Long> map = cooldowns.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>());
        long ready = map.getOrDefault(ability, 0L);
        if (now < ready) {
            p.sendActionBar(ChatColor.LIGHT_PURPLE + ability + " cooldown: " + ((ready - now + 999) / 1000) + "s");
            return true;
        }
        map.put(ability, now + millis);
        return false;
    }

    private boolean canDamage(Player source, Entity target) {
        if (!(target instanceof LivingEntity living) || target.equals(source)) return false;
        if (target instanceof Player && !getConfig().getBoolean("pvp-enabled", true)) return false;
        return living.getHealth() > 0;
    }

    private void damageNearby(Player source, Location center, double radius, double damage, double knockback, boolean upward) {
        for (Entity entity : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!canDamage(source, entity)) continue;
            LivingEntity target = (LivingEntity) entity;
            target.damage(damage, source);
            Vector direction = target.getLocation().toVector().subtract(center.toVector());
            if (direction.lengthSquared() < 0.01) direction = new Vector(0, 0, 1);
            direction.normalize().multiply(knockback);
            if (upward) direction.setY(Math.max(0.65, direction.getY() + 0.55));
            target.setVelocity(direction);
            target.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, target.getLocation().add(0, 1, 0), 10, 0.35, 0.45, 0.35, 0.1);
            target.getWorld().spawnParticle(Particle.REVERSE_PORTAL, target.getLocation().add(0, 1, 0), 18, 0.4, 0.6, 0.4, 0.05);
        }
    }

    private void ring(Location center, double radius, Particle particle, int points) {
        World world = center.getWorld();
        for (int i = 0; i < points; i++) {
            double angle = 2 * Math.PI * i / points;
            Location loc = center.clone().add(Math.cos(angle) * radius, 0.15, Math.sin(angle) * radius);
            world.spawnParticle(particle, loc, 2, 0.08, 0.12, 0.08, 0.02);
        }
    }

    private void divineThunder(Player p) {
        if (onCooldown(p, "Divine Thunder", 3000)) return;
        Location target = p.getTargetBlockExact(24) == null
                ? p.getLocation().add(p.getLocation().getDirection().multiply(8))
                : p.getTargetBlockExact(24).getLocation().add(0.5, 1, 0.5);
        World w = p.getWorld();
        w.playSound(target, Sound.ITEM_TRIDENT_THUNDER, 1.8f, 0.65f);
        w.spawnParticle(Particle.FLASH, target, 3, 1.0, 1.0, 1.0, 0);
        double radius = getConfig().getDouble("radius.divine-thunder", 6.0);
        for (int i = 0; i < 5; i++) {
            double angle = (Math.PI * 2 * i / 5);
            Location strike = target.clone().add(Math.cos(angle) * (1.5 + i * 0.4), 0, Math.sin(angle) * (1.5 + i * 0.4));
            w.strikeLightningEffect(strike);
            w.spawnParticle(Particle.ELECTRIC_SPARK, strike.clone().add(0, 1, 0), 35, 0.7, 1.2, 0.7, 0.15);
            w.spawnParticle(Particle.REVERSE_PORTAL, strike.clone().add(0, 1, 0), 25, 0.7, 1.0, 0.7, 0.08);
        }
        damageNearby(p, target, radius, getConfig().getDouble("damage.divine-thunder", 18.0), 1.5, true);
    }

    private void worldBreaker(Player p) {
        if (onCooldown(p, "World Breaker", 4000)) return;
        Location center = p.getLocation();
        World w = p.getWorld();
        w.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.7f, 0.65f);
        w.spawnParticle(Particle.EXPLOSION, center, 2, 0.5, 0.1, 0.5, 0);
        for (double r = 1; r <= 8; r += 1.5) ring(center, r, Particle.REVERSE_PORTAL, 20);
        w.spawnParticle(Particle.BLOCK, center, 70, 3, 0.15, 3, 0.12, Material.DEEPSLATE.createBlockData());
        damageNearby(p, center, getConfig().getDouble("radius.world-breaker", 8.0),
                getConfig().getDouble("damage.world-breaker", 14.0), 1.8, true);
    }

    private void voidCollapse(Player p) {
        if (onCooldown(p, "Void Collapse", 5000)) return;
        Location center = p.getLocation().add(p.getLocation().getDirection().multiply(5));
        World w = p.getWorld();
        w.playSound(center, Sound.BLOCK_PORTAL_AMBIENT, 1.8f, 0.45f);
        for (int t = 0; t < 3; t++) {
            final int stage = t;
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (!center.getWorld().equals(w)) return;
                for (Entity entity : w.getNearbyEntities(center, 7, 7, 7)) {
                    if (!canDamage(p, entity)) continue;
                    Vector pull = center.toVector().subtract(entity.getLocation().toVector()).normalize().multiply(0.7);
                    pull.setY(pull.getY() + 0.18);
                    entity.setVelocity(pull);
                }
                w.spawnParticle(Particle.REVERSE_PORTAL, center, 100, 2.3, 2.3, 2.3, 0.08);
                w.spawnParticle(Particle.DRAGON_BREATH, center, 50, 1.5, 1.5, 1.5, 0.04);
                if (stage == 2) {
                    w.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 2f, 0.55f);
                    w.spawnParticle(Particle.FLASH, center, 2, 1, 1, 1, 0);
                    damageNearby(p, center, getConfig().getDouble("radius.void-collapse", 7.0),
                            getConfig().getDouble("damage.void-collapse", 20.0), 2.2, true);
                }
            }, t * 8L);
        }
    }

    private void startGodMode(Player p) {
        if (onCooldown(p, "God Mode", 35000)) return;
        UUID id = p.getUniqueId();
        godMode.add(id);
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 600, 4, false, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 600, 2, false, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 600, 3, false, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 600, 0, false, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 600, 1, false, true, true));
        p.getWorld().playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.5f, 0.6f);
        p.sendTitle(ChatColor.DARK_PURPLE + "GOD MODE", ChatColor.LIGHT_PURPLE + "30 seconds of divine power", 5, 35, 10);
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            Player online = Bukkit.getPlayer(id);
            if (online == null || !godMode.contains(id) || !isHyphirion(online.getInventory().getItemInMainHand())) {
                if (online != null) clearGodMode(online);
                task.cancel();
                return;
            }
            online.getWorld().spawnParticle(Particle.REVERSE_PORTAL, online.getLocation().add(0, 1, 0), 12, 0.55, 0.8, 0.55, 0.02);
            online.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, online.getLocation().add(0, 1, 0), 5, 0.4, 0.6, 0.4, 0.03);
        }, 0L, 5L);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            Player online = Bukkit.getPlayer(id);
            if (online != null) clearGodMode(online);
        }, 600L);
    }

    private void clearGodMode(Player p) {
        godMode.remove(p.getUniqueId());
        p.removePotionEffect(PotionEffectType.STRENGTH);
        p.removePotionEffect(PotionEffectType.REGENERATION);
        p.removePotionEffect(PotionEffectType.RESISTANCE);
        p.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        p.removePotionEffect(PotionEffectType.SPEED);
        p.sendMessage(ChatColor.GRAY + "God Mode has ended.");
    }

    private void heavensJudgment(Player p) {
        if (onCooldown(p, "Heaven's Judgment", 5000)) return;
        Entity target = p.getTargetEntity(30);
        if (!(target instanceof LivingEntity living) || !canDamage(p, living)) {
            p.sendActionBar(ChatColor.RED + "Aim at a mob or player first.");
            return;
        }
        Location mark = living.getLocation().add(0, 1, 0);
        World w = living.getWorld();
        w.playSound(mark, Sound.BLOCK_BEACON_POWER_SELECT, 1.6f, 0.5f);
        w.spawnParticle(Particle.END_ROD, mark, 50, 0.5, 0.8, 0.5, 0.03);
        for (int i = 0; i < 3; i++) {
            final int step = i;
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (!living.isValid() || living.isDead()) return;
                Location loc = living.getLocation();
                w.spawnParticle(Particle.ELECTRIC_SPARK, loc.add(0, 1, 0), 60, 0.5, 1.0, 0.5, 0.08);
                if (step == 2) {
                    w.strikeLightningEffect(living.getLocation());
                    living.damage(getConfig().getDouble("damage.heavens-judgment", 30.0), p);
                    living.setVelocity(new Vector(0, 1.3, 0));
                    w.spawnParticle(Particle.FLASH, living.getLocation().add(0, 1, 0), 2);
                    w.spawnParticle(Particle.REVERSE_PORTAL, living.getLocation().add(0, 1, 0), 80, 1.2, 1.2, 1.2, 0.08);
                }
            }, i * 8L);
        }
    }

    private void skybreakerDash(Player p) {
        long now = System.currentTimeMillis();
        long last = lastJumpTrigger.getOrDefault(p.getUniqueId(), 0L);
        lastJumpTrigger.put(p.getUniqueId(), now);
        if (now - last < 250) return;
        Vector direction = p.getLocation().getDirection().normalize().multiply(2.7);
        direction.setY(Math.max(direction.getY(), 0.35));
        p.setVelocity(direction);
        p.setFallDistance(0);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1.0f, 1.7f);
        p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p.getLocation(), 45, 0.5, 0.5, 0.5, 0.1);
        p.getWorld().spawnParticle(Particle.REVERSE_PORTAL, p.getLocation(), 35, 0.5, 0.7, 0.5, 0.05);
    }

    private void divineDive(Player p) {
        if (onCooldown(p, "Divine Dive", 4000)) return;
        Location loc = p.getLocation();
        diveStarted.put(p.getUniqueId(), System.currentTimeMillis());
        Vector dive = p.getLocation().getDirection().multiply(0.4);
        dive.setY(-2.8);
        p.setVelocity(dive);
        p.setFallDistance(0);
        p.getWorld().playSound(loc, Sound.ENTITY_WIND_CHARGE_WIND_BURST, 1.4f, 0.5f);
        p.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 35, 0.4, 0.5, 0.4, 0.1);
        UUID id = p.getUniqueId();
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            Player online = Bukkit.getPlayer(id);
            if (online == null || !online.isOnline()) { task.cancel(); return; }
            Location at = online.getLocation();
            online.getWorld().spawnParticle(Particle.REVERSE_PORTAL, at, 12, 0.3, 0.3, 0.3, 0.02);
            if (online.isOnGround()) {
                long started = diveStarted.getOrDefault(id, System.currentTimeMillis());
                double height = Math.min(getConfig().getDouble("divine-dive-height-cap", 20.0),
                        Math.max(0, loc.getY() - at.getY()));
                double radius = Math.min(getConfig().getDouble("radius.divine-dive-max", 12.0),
                        getConfig().getDouble("radius.divine-dive-base", 6.0) + height * 0.25);
                double damage = Math.min(getConfig().getDouble("damage.divine-dive-max", 35.0),
                        getConfig().getDouble("damage.divine-dive-base", 12.0) + height * getConfig().getDouble("damage.divine-dive-per-block", 1.5));
                at.getWorld().playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 1.8f, 0.6f);
                at.getWorld().spawnParticle(Particle.EXPLOSION, at, 3, 0.5, 0.1, 0.5, 0);
                for (double r = 1; r <= radius; r += 1.5) ring(at, r, Particle.REVERSE_PORTAL, 24);
                at.getWorld().spawnParticle(Particle.BLOCK, at, 90, radius / 2, 0.15, radius / 2, 0.12, Material.DEEPSLATE.createBlockData());
                damageNearby(online, at, radius, damage, 2.0, true);
                task.cancel();
            }
        }, 1L, 1L);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        Player p = event.getPlayer();
        if (!isHyphirion(event.getItem())) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
        event.setCancelled(true);
        if (p.isSneaking() && p.isOnGround() && p.getLocation().getDirection().getY() > 0.65) {
            startGodMode(p);
        } else if (p.isSneaking() && !p.isOnGround()) {
            divineDive(p);
        } else if (p.isSneaking()) {
            worldBreaker(p);
        } else {
            divineThunder(p);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSwing(PlayerAnimationEvent event) {
        Player p = event.getPlayer();
        if (!isHyphirion(p.getInventory().getItemInMainHand())) return;
        long now = System.currentTimeMillis();
        long previous = lastSwing.getOrDefault(p.getUniqueId(), 0L);
        lastSwing.put(p.getUniqueId(), now);
        if (now - previous <= 350) {
            lastSwing.put(p.getUniqueId(), 0L);
            voidCollapse(p);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        Player p = event.getPlayer();
        if (!isHyphirion(p.getInventory().getItemInMainHand()) || !p.isSneaking()) return;
        event.setCancelled(true);
        heavensJudgment(p);
    }

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent event) {
        Player p = event.getPlayer();
        if (!isHyphirion(p.getInventory().getItemInMainHand())) return;
        event.setCancelled(true);
        skybreakerDash(p);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player p = event.getPlayer();
        boolean holding = isHyphirion(p.getInventory().getItemInMainHand());

        // Enable the existing double-jump/flight-toggle input while grounded with the mace.
        // Never override Creative/Spectator flight permissions when the mace is not held.
        if (holding && p.isOnGround() && p.getGameMode() != GameMode.CREATIVE
                && p.getGameMode() != GameMode.SPECTATOR) {
            p.setAllowFlight(true);
        } else if (!holding && p.getGameMode() != GameMode.CREATIVE
                && p.getGameMode() != GameMode.SPECTATOR && p.getAllowFlight()) {
            p.setAllowFlight(false);
            if (p.isFlying()) p.setFlying(false);
        }

        if (godMode.contains(p.getUniqueId()) && !holding) clearGodMode(p);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player p && godMode.contains(p.getUniqueId())
                && (event.getCause() == EntityDamageEvent.DamageCause.FALL
                || event.getCause() == EntityDamageEvent.DamageCause.FIRE
                || event.getCause() == EntityDamageEvent.DamageCause.FIRE_TICK
                || event.getCause() == EntityDamageEvent.DamageCause.LAVA)) {
            event.setCancelled(true);
        }
    }
}
